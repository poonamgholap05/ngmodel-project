package com.cjc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuditNGmodelApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditNGmodelApplication.class, args);
	}

}
